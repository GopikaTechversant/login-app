export const users=[
    {username:"gopika",email:"gopika@gmail.com",role:"admin",password:"123456"},
    {username:"sritha",email:"sritha@gmail.com",role:"user",password:"123456"},
    {username:"chris",email:"chris@gmail.com",role:"admin",password:"123456"},
    {username:"gokul",email:"gokul@gmail.com",role:"user",password:"123456"},
]
